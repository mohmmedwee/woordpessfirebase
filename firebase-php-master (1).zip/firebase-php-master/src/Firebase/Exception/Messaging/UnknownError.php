<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception\Messaging;

use Kreait\Firebase\Exception\MessagingException;

class UnknownError extends MessagingException
{
}
