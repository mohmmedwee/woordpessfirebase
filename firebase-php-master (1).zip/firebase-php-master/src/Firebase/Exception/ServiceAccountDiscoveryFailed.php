<?php

namespace Kreait\Firebase\Exception;

class ServiceAccountDiscoveryFailed extends LogicException
{
}
