<?php

namespace Kreait\Firebase\Exception;

class OutOfBoundsException extends \OutOfBoundsException implements FirebaseException
{
}
