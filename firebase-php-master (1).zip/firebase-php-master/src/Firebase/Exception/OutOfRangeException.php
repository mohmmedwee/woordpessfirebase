<?php

namespace Kreait\Firebase\Exception;

class OutOfRangeException extends \OutOfRangeException implements FirebaseException
{
}
