<?php

namespace Kreait\Firebase\Exception;

class IndexNotDefined extends QueryException
{
}
