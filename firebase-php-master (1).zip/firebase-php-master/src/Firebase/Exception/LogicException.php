<?php

namespace Kreait\Firebase\Exception;

class LogicException extends \LogicException implements FirebaseException
{
}
