<?php

namespace Kreait\Firebase\Database\Query;

interface Filter extends Modifier
{
}
