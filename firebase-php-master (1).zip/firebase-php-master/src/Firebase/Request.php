<?php

declare(strict_types=1);

namespace Kreait\Firebase;

interface Request extends \JsonSerializable
{
}
